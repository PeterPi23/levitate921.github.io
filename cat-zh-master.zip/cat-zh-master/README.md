# Kittens Game （猫国建设者）  #

### 网页版本链接 ###
* 最新汉化版本（v 1.4.6.2.d (29 may 2019)）：http://likexia.gitee.io/cat-zh/
* 备用汉化版（V 1.4.5.2b）：http://cnh5.gitee.io/cat-zh/
* 之前汉化版（V 1.4.0.7）：http://kittens.applinzi.com/
* 作者最新英文原版（v 1.4.6.2.d (29 may 2019)）：http://bloodrizer.ru/games/kittens/

1.4以下版本的存档不能用在最新版上哦~
* U77汉化版（V 1.0.5.8）http://www.u77.com/game/4649

### 手机版本下载 ###
手机版本为付费版本，大概6元，有需要的朋友可以移步下载，目前最新的手机版本已经加入了中文，可以在菜单里面设置。
* 安卓版（v 1.4.6.2c）US$1.99：https://play.google.com/store/apps/details?id=com.nuclearunicorn.kittensgame
* ios版：https://itunes.apple.com/us/app/kittens-game/id1198099725?mt=8

### No ES6 please ###

KG ecosystem have to support about 20.000 different android devices, iOS, os and browser versions dating 1980, chrome/FF/IE/Edge/webkit of all possible releases.
We support IE6. We support browsers that does not know how to work with local storage or web workers. I'm not sure but it might acutally work on Netscape, Links or Mosaic.

Please, no ()=>{}, const, require, webpackers, etc.



### 其它链接 ###
* 游戏源码：https://bitbucket.org/bloodrizer/kitten-game
* 游戏百科：http://bloodrizer.ru/games/kittens/wiki/index.php?page=Main+page

### 声明 ###
* 此汉化版本只是为了方便广大中国玩家进行游戏。
* 游戏版权归原作者 http://bloodrizer.ru/ 所有。
* 非常感谢 @a253208088 @Domaron 帮助汉化本游戏。


