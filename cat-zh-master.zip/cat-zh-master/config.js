dojo.declare("classes.KGConfig", null, {
    statics: {
        disableWebWorkers: false,
        locales: ["ru", "ja", "br", "es", "fr", "cz", "zh", "pl", "chs"],
        schemes: ["dark", "grassy", "sleek", "gold", "space", "wood", "school", "fluid", "vessel", "minimalist", "oil", "unicorn", "anthracite"]
    }
});
